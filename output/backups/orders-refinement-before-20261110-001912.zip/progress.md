Original prompt: Follow the uploaded “My Panaderya — Comprehensive Visual QA and UI Repair” text, inspect the two uploaded images and My_Panaderya_Touch_Fixed_Source.zip, repair its illustrated UI, and validate real renders and interactions at 2000×1200, 1280×800 and another landscape size. Preserve gameplay and do not push or deploy.

## Scope and inspection

- The supplied ZIP is a standalone 1619×971 DOM UI demo, explicitly separate from the production repository. Work is isolated in `My_Panaderya_Visual_Repair/`; existing production changes and save/worksheet code are preserved.
- Read the uploaded text, README, CODEX_HANDOFF, HTML, CSS and JS; viewed both user images and a contact sheet of the source assets.
- Source map: `index.html` assembles scenery, cabinet, clipboard and modal; `styles.css` contains several competing override passes; `app.js` holds demo catalog/state, renderMenu/renderTickets, modal screens, package/coin transactions, pointer feedback and two scrollbars.
- Actual limitations inherited from ZIP: no persistence, production worksheet, Mastery or upgrade systems. Do not invent these or substitute demo economics into production.
- Causes found: sliced cabinet frame repeated in border-image; cabinet geometry moves under separately anchored header; ticket internal widths too small; baked package sign duplicated by another sign; source art contains neighboring fragments and mismatched foliage; multiple CSS overrides and absolute internal ticket offsets.

## Visual implementation plan

- Visual thesis: one warm, illustrated bakery assembled from clean independent artwork, with a glass showcase as the focal point and the original approved composition as the source of truth.
- Content plan: fixed logo/HUD, packages alcove, shared cabinet header with Boost, scrollable equipped foods, clipboard tickets with fixed utilities, three illustrated navigation buttons, consistent illustrated popups.
- Interaction thesis: local pressed artwork without layout movement, restrained food aura/rainbow sparkle, popup entrance with reduced-motion support; native touch scrolling plus synchronized draggable rails.
- Reconstruct defective scenery and component art with imagegen; preserve the existing Filipino food miniatures, package props and valid illustrated assets.

## Validation to complete

- Capture baseline and repaired renders; compare against approved image.
- Exercise 1/3/5/9/10/16 foods, partial rows, clipping, wheels, touch swipes, thumbs, tracks and arrows.
- Exercise navigation, all popup types actually present, purchase/equip, wrong/right answer, single coin claim and dynamic Boost/wallet.
- Run installed web-game client and Playwright; inspect screenshots and console output.
- Package repaired standalone source and document its inherited demo limitations.

## Implemented and checked

- Rebuilt the supplied demo in its isolated folder with one 2000×1200 composition, clean generated scenery/cabinet/clipboard/navigation/sign/header art, native scroll viewports and shared reusable ticket/scrollbar components. No production code/economy/save/worksheet changes.
- Preserved source foods, catalog IDs, prices, sample package distribution and coin reward calculation. Popup surfaces remain illustrated; clean common title art has real text. Pointer cancellation, modal focus and reduced-motion behavior are covered.
- Inspected baseline and repaired screenshots. Corrected food rows crossing the cabinet trim, a duplicated clipboard title, a stray Buy mark and detached fragments in two package props after visual inspection.
- Full Node suite: 125/125 passed. Parent production hub runner passed Edge and WebKit. Standalone browser runner passed Edge and WebKit at 2000×1200, 1280×800 and 1440×900, all six required food counts, both scrollbars, real Chromium touch swipes/thumbs, navigation/popups, nine-tier purchases, equipment/Boost and one-time coin claims.
- Installed web-game client ran and its home/Packages screenshots and state output were inspected. Direct file opening also passed without console errors.
- Final extended disabled-state suite passed Edge and WebKit. Production worksheet regression passed all carrying/click/drag/swipe/reload, unique claim and degraded-API/dropped-delivery cases; separate smoke suite passed 5/5.
- Inspected reference/before/after, both six-count sheets and twelve popup views. Fixed a final popup scroll restoration bug discovered in the review; focused Edge/WebKit reopen/wheel/touch checks passed at both main sizes. Installed web-game client also passed the Collection state and its screenshot was inspected.
- Completed: `output/My_Panaderya_Visual_Repair.zip` contains the repaired standalone source, tests, docs, visual comparisons and QA evidence. Archive CRC and matching-current-source checks passed. Task-owned preview server and Playwright inspection browser were closed.
- The supplied demo retains its inherited sample economy, answer field and absence of persistence/Mastery/upgrade systems; production logic remains separate. Future owner review: aesthetic acceptance and physical-tablet validation. A later production integration is a separate task and must preserve the actual worksheet/economy/save behavior.

## Latest owner request: FULL UI replacement in the ACTUAL project

- Request: `C:/Users/USER/.codex/attachments/de12c75c-5dd7-465a-b1cd-0755b632f84c/Pasted text.txt`. The actual root game must use the repaired ZIP UI, with the original worksheet and existing Packages shop as explicit visual exceptions. The repaired ZIP is now a source/reference, not the destination.
- Safe backup made before edits: `output/backups/production-ui-before-20261109-214150.zip` plus SHA-256 JSON manifest, including existing uncommitted source/styles/worksheet/art/tests.
- Actual production files now changed: `index.html`, `src/environment-entry.js`, `src/ui/bakery-hub.js`, `src/ui/illustrated-art.js`, `styles/bakery-hub.css`, `styles/bakery-interface.css`; added `src/ui/illustrated-controls.js`, `styles/bakery-preserved-interfaces.css`, and transferred art in `assets/bakery-ui/`.
- No demo state, economy, catalog, package odds or answer field is loaded. Real `g`, production food identities/values, real order generation/runs, package controllers, selection/Mastery and saves drive the new UI. Sprite mapping uses actual catalog IDs rather than the ZIP's inconsistent sample food names.
- `src/game/rewards.js` only extracts the unchanged rounding formula into `orderCoinQuote`, shared by actual run creation and ticket display; saved run budgets remain authoritative. The worksheet engine/bridge and package controllers are unchanged.
- Replaced old home renderer/CSS/markup. Removed old room/counter/register/shelf art and four unused plaque/frame SVGs after auditing runtime references; all are in the backup. The archived environment mounts only on its explicit query route. The obsolete default layout-script load was removed.
- Existing hub browser regression passed Edge/WebKit. New actual-project suite passed Edge/WebKit before the final empty-menu and extra shared-popup refinements. Both before/after style baselines match for the preserved package shop (189 elements) and worksheet shell (37 elements). The original worksheet runner passed real 79×18 and 19×9, carry, drag, swipe, settings, reload, exact coin claims and degraded API/delivery cases.
- New checks caught and fixed a missing thumb ID, inherited arrow min-height overlapping its track, inherited food art width, and old collection-container styling. They also verify zero-scroll rails hide, genuine native touch gestures work, and initial popup scroll resets.
- Completed final verification: 126/126 Node tests; expanded actual-root integration suite passed Edge and WebKit after the empty-menu and popup refinements; archive-route checks passed both engines. Installed web-game client rendered actual home, collection and original worksheet; inspected its screenshots/state and a separate actual-root Playwright CLI Collection screenshot.
- Visually inspected the actual-root/repaired-source comparison, seven food-count states, scrolled last row, and eight-view popup/worksheet review. New art composition matches the source with real catalog/Boost/order substitutions. Final SHA-256 audit confirms 27 protected files unchanged against the pre-edit backup; only rewards.js has the documented equivalent quote extraction.
- Final implementation, removed components, preserved exceptions, exact test outcomes and screenshot links are in `docs/PRODUCTION_UI_REPLACEMENT.md`. Task-owned preview server and Playwright inspection session are stopped. No push/deployment. Remaining external review: physical tablet validation and owner aesthetic acceptance.

## Latest owner request: comprehensive UI refinement and visual cleanup

- Request: `C:/Users/USER/.codex/attachments/feca5bee-0883-4931-bf1b-dee609a06fa4/Pasted text.txt` and `My Panaderya UI Fix Handoff.png`; incorporated the subsequent sign-size/overlap and upper-left architecture correction without restarting the integration.
- Backed up 149 task-start files in `output/backups/ui-refinement-before-20261109-232110.zip` with SHA-256 manifest. Existing work and user saves were preserved.
- Reconstructed the transparent sign and repaired the actual room arch using built-in image editing; exact prompts/final paths in `assets/bakery-ui/refinement-provenance.json`. Native standalone SVG top controls and scalable 9-slice popup frame replace defective crops. Final sign is about 19% larger than the initial refined asset render, centered on the cabinet with a slight wood-frame overlap and clear Menu/Boost controls.
- Tickets now use all eight saved production type definitions/icons, coin art/tier, original food/tray equation and actual progress; no visible reward name/payout or separate play arrow. Entire tickets invoke the original start/resume path. Gameplay/odds are unchanged.
- Rebuilt content-sized shared overlays, illustrated help, compact persisted settings/Advanced, contribution-based Boost, actual odds, collection/details/bulk actions, concise sale confirmation and external receipt. Preserved original worksheet/claim surface and existing package-shop design. Corrected old pseudo-decoration, selected-food contrast, inherited button styles and scaled touch controls; scrollbar thumb sizing respects its real minimum size.
- Final observed validation: 127/127 Node tests; existing hub and production integration runners passed Edge/WebKit; new refinement runner passed Edge/WebKit at 2000×1200,1280×800,1024×768, including eight tiers, 44px controls, settings persistence, original worksheet resumption and one-time receipt claim. Original worksheet runner passed real 79×18/19×9, carry, click/drag, Undo, swipe, reload, settings and degraded API/message delivery cases.
- Installed web-game client screenshots/state for actual home/help/collection/original worksheet were inspected; Playwright CLI inspected the real root app and final composition. Final native Chromium scrollbar check completed. Inspected before/after home/corner, both full home sizes and the ten-view popup contact sheet. All 29 protected files are byte-identical to this pass's backup.
- Handoff: `docs/UI_REFINEMENT.md`, artifacts in `output/playwright/refinement/`. No push/deployment. Remaining external review: physical Android tablet testing and owner aesthetic acceptance.
