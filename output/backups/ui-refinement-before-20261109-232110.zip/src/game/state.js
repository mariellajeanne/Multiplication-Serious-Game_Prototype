/* Panaderya Quest — src/game/state.js
 * Modularized from the original playable prototype.
 * Loaded as classic scripts in index.html, in dependency order.
 */
const fresh=()=>({progressionVersion:PROGRESSION_VERSION,economyVersion:ECONOMY_BALANCE.version,frame11Version:1,coinRewardsVersion:1,legacyPackageFoods:Array.from({length:9},()=>[]),uniqueFoodsVersion:1,recipeCeilings:{pandesal:0},orderRuns:{},claimedOrders:{},packages:Array(9).fill(0),packageRevision:0,rarityCount:8,bakeryLevel:1,bakerySpent:0,autoEquip:'off',foodLevelCredits:{},orderClock:0,orderRefreshAt:0,coins:250,completed:0,mastery:0,permanentLuck:0,owned:[{uid:1,id:'pandesal',level:1,fusion:1,spent:0}],discovered:['pandesal'],uidNext:2,ingredients:{},decor:0,staff:{until:0,rate:0},mode:'normal',lives:3,board:[],ticketSeq:0,sound:true,musicOn:false,tutorialArrows:true,guideGraduated:false,menuSlots:1,activeMenu:[1],helpSeen:false,seenUnlocks:[],tutorialIndex:0,learning:{correct:0,mistakes:0},run:null});
let g,previousSave;try{previousSave=localStorage.getItem('panaderyaQuestV2');g=JSON.parse(previousSave)||fresh()}catch(_){g=fresh()}
if(!g.owned||!('completed' in g)){g=fresh()}
if(g.progressionVersion!==PROGRESSION_VERSION){
 try{if(previousSave&&!localStorage.getItem('panaderyaQuestV2BeforeProgression'))localStorage.setItem('panaderyaQuestV2BeforeProgression',previousSave)}catch(_){}
 migrateProgression(g);
}
if(!Number.isInteger(g.menuSlots))g.menuSlots=1;if(!Array.isArray(g.activeMenu))g.activeMenu=g.owned.slice(0,g.menuSlots).map(x=>x.uid);if(typeof g.tutorialArrows!=='boolean')g.tutorialArrows=true;if(typeof g.musicOn!=='boolean')g.musicOn=false;
function migrateFrame11(state){
 state.orderRuns=state.orderRuns||{};state.claimedOrders=state.claimedOrders||{};
 state.packages=Array.from({length:9},(_,i)=>Math.max(0,Math.floor(state.packages?.[i]||0)));
 state.recipeCeilings=state.recipeCeilings||{};
 // Repricing keeps every asset and pending reward; old price-based Undo quotes expire.
 if(state.economyVersion!==ECONOMY_BALANCE.version){
  // Existing players retain package types unlocked under the previous 10-level gates.
  state.packageTierUnlocks=[...new Set([...(state.packageTierUnlocks||[]),...PACKAGE_SHOP.filter(t=>state.bakeryLevel>=1+t.rank*10).map(t=>t.rank)])];
  const menu={};for(const food of state.owned.filter(o=>state.activeMenu.includes(o.uid)))menu[food.id]=Math.max(menu[food.id]||0,individualValue(food));
  state.economyPeakBase=Math.max(1,Object.values(menu).reduce((a,b)=>a+b,0));
  state.purchaseUndo=null;state.economyVersion=ECONOMY_BALANCE.version;
 }
 state.packageRevision=Math.max(0,Math.floor(state.packageRevision||0));
 if(!state.frame11Version){
  // Previously earned chests guaranteed a food rarity. Keep that promise for
  // pending legacy rewards instead of reinterpreting them as a Luck-type draw.
  for(const run of [state.run,...Object.values(state.orderRuns)].filter(Boolean))
   run.chests=(run.chests||[]).map(chest=>typeof chest==='number'?{rarity:chest,legacyFoodRarity:chest}:{...chest,legacyFoodRarity:chest.rarity});
  for(const food of FOOD){const copies=state.owned.filter(o=>o.id===food.id);if(!copies.length)continue;
   state.recipeCeilings[food.id]=Math.max(...copies.map(recipeMastery))+copies.length-1+(state.foodLevelCredits?.[food.id]||0);
  }
  state.frame11Version=1;
 }
 for(const id of Object.keys(state.orderRuns))if(state.claimedOrders[id])delete state.orderRuns[id];
 if(state.run&&state.claimedOrders[state.run.ticket.id])state.run=null;
 state.board=state.board.filter(ticket=>!state.claimedOrders[ticket.id]);
 if(state.run){const existing=state.orderRuns[state.run.ticket.id];state.run=existing||state.run;state.orderRuns[state.run.ticket.id]=state.run;}
 for(const r of Object.values(state.orderRuns))if(!state.claimedOrders[r.ticket.id]&&!state.board.some(t=>t.id===r.ticket.id))state.board.unshift(r.ticket);
 const started=state.board.filter(t=>state.orderRuns[t.id]);
 state.board=[...started,...state.board.filter(t=>!state.orderRuns[t.id]).slice(0,Math.max(0,ORDER_LIMIT-started.length))];
 state.ticketSeq=Math.max(state.ticketSeq||0,...state.board.map(t=>Number(t.id)||0));
 // Retain unique recipes and consolidate older multiple-copy investments before assignment validation.
 consolidateOwnedFoods(state);
 const seen=new Set();state.activeMenu=state.activeMenu.filter(uid=>{const o=state.owned.find(x=>x.uid===uid);if(!o||seen.has(o.id))return false;seen.add(o.id);return true}).slice(0,state.menuSlots);
 migrateCoinRewards(state);
 reconcileOrderFoods(state);
 return state;
}
// Convert already-earned package promises to counter stock once. No reward RNG
// runs during migration; guaranteed legacy food ranks stay attached to that stock.
function migrateCoinRewards(state){
 state.legacyPackageFoods=Array.from({length:9},(_,i)=>state.legacyPackageFoods?.[i]||[]);
 const runs=Object.values(state.orderRuns);
 for(const ticket of [...state.board,...runs.map(r=>r.ticket)]){
  ticket.coinTier=ticketCoinTier(ticket);ticket.orderLabel=ticketOrderLabel(ticket);
  ticket.orderIcon=ticket.orderIcon||COIN_ORDER_ICONS[ticket.coinTier];
  if(!Number.isFinite(ticket.base))ticket.base=ticketBase(ticket.coinTier);
  delete ticket.packages;
 }
 for(const r of runs){
  if(r.coinRewardsVersion!==1){
   if(!state.claimedOrders[r.ticket.id])for(const chest of r.chests||[]){
    const rank=clamp(typeof chest==='number'?chest:chest.rarity||0,0,7);state.packages[rank]++;
    if(Number.isInteger(chest.legacyFoodRarity))state.legacyPackageFoods[rank].push(chest.legacyFoodRarity);
   }
   // Older saves contain a fixed budget, but no original boost snapshot.
   // Preserve the promised budget (and completed pool) without recalculation.
   r.baseCoins=r.ticket.base;r.bakersBoost=(r.phase==='claim'?r.pool:r.budget)/r.baseCoins;
   if(!Number.isFinite(r.bakersBoost))r.bakersBoost=1;
   r.budget=Number.isFinite(r.budget)?r.budget:Math.round(r.baseCoins*r.bakersBoost);
   r.savedReward=true;r.coinRewardsVersion=1;
  }
  delete r.chests;delete r.luck;delete r.guaranteedPackages;
 }
 state.coinRewardsVersion=1;
}
if(previousSave&&g.uniqueFoodsVersion!==1){try{if(!localStorage.getItem('panaderyaQuestV2BeforeUniqueFoods'))localStorage.setItem('panaderyaQuestV2BeforeUniqueFoods',previousSave)}catch(_){} }
migrateFrame11(g);
migrateBakeryHub(g);
// One-time removal preserves assets and frozen order budgets, never recalculates rewards.
function migrateBakeryHub(state){
 if(state.bakeryHubVersion===1)return state;
 const level=Math.max(1,Number(state.bakeryLevel)||1);
 state.retiredBakeryPower={level,spent:state.bakerySpent||0};
 state.packageTierUnlocks=[...new Set([...(state.packageTierUnlocks||[]),...PACKAGE_SHOP.filter(t=>t.rank<8&&level>=t.unlock).map(t=>t.rank)])];
 // Helpers are supplemental: remove the retired factor from their future ticks only.
 if(state.staff?.until>Date.now())state.staff.rate/=Math.pow(1.085,Math.min(5000,level-1));
 state.bakeryLevel=1;state.bakerySpent=0;state.purchaseUndo=null;state.bakeryHubVersion=1;
 return state;
}
// Retired Kitchen fields never participate in values, prices or save validation.
// Commit old Undo records: their signatures include the removed equipment field.
if(Object.prototype.hasOwnProperty.call(g,'equipment')||Object.prototype.hasOwnProperty.call(g,'kitchenSpent'))g.purchaseUndo=null;
delete g.equipment;delete g.kitchenSpent;
g.seenUnlocks=(g.seenUnlocks||[]).filter(key=>key!=='kitchen');
// Old established players keep their saved guide preference.
if(typeof g.guideGraduated!=='boolean')g.guideGraduated=g.completed>=3;
function graduateGuideAfterOrder(){if(g.completed>=3&&!g.guideGraduated){g.guideGraduated=true;g.tutorialArrows=false;}}
let modal=null;let music=null;let musicTimer=null;let animationTimers=[];let modalReturnFocus=null;
const F=id=>FOOD.find(x=>x.id===id);
const rarityLabel=r=>`★${r+1} · ${RARITIES[r]}`;
const rarityTag=r=>`<span class="tag rarity-r${r} ${RARITIES[r].toLowerCase().replaceAll(' ','-')}">${rarityLabel(r)}</span>`;
const foodValue=individualValue;
const foodSum=()=>{const best={};for(const o of g.owned.filter(x=>g.activeMenu.includes(x.uid)))best[o.id]=Math.max(best[o.id]||0,foodValue(o));return Object.values(best).reduce((a,b)=>a+b,0)};
const decorBonus=()=>1; // compatibility alias, no hidden bakery-wide multiplier
const bakeryValue=()=>Math.max(1,foodSum());
const tierLevel=()=>g.completed<2?0:g.completed<4?1:g.completed<7?2:g.completed<11?3:g.completed<16?4:5;
const masterStage=()=>Math.min(5,Math.floor(g.mastery/4));
const highestRarity=()=>7;
function ticketLuckMastery(){return Math.max(g.mastery||0,(g.permanentLuck||0)*4)}
function ticketRarity(){return drawRank(ticketProbabilities(ticketLuckMastery()))}
function menuRecipes(state=g){return [...new Set((state.activeMenu||[]).map(uid=>state.owned.find(o=>o.uid===uid)?.id).filter(id=>FOOD.some(f=>f.id===id)))]}
function assignedOrderFood(ticket,state=g,locked=false){
 const equipped=menuRecipes(state),valid=FOOD.some(f=>f.id===ticket.foodId);
 if(valid&&(locked||equipped.includes(ticket.foodId)||!equipped.length))return ticket.foodId;
 // Use ticket identity, never reward RNG, to distribute orders across real menu recipes.
 const candidates=equipped.length?equipped:state.owned.filter(o=>FOOD.some(f=>f.id===o.id)).map(o=>o.id);
 return candidates[Math.abs(Number(ticket.id)||0)%candidates.length]||FOOD[0].id;
}
function reconcileOrderFoods(state=g){
 for(const run of Object.values(state.orderRuns||{}))if(run?.ticket)run.ticket.foodId=assignedOrderFood(run.ticket,state,true);
 for(const ticket of state.board||[]){const run=state.orderRuns?.[ticket.id];ticket.foodId=run?.ticket?.foodId||assignedOrderFood(ticket,state,false)}
 return state;
}
function makeTicket(){const rarity=ticketRarity(),dims=TICKET_DIMS[rarity];const aMin=10**(dims[0]-1),aMax=10**dims[0]-1,bMin=10**(dims[1]-1),bMax=10**dims[1]-1;const a=aMin+Math.floor(Math.random()*(aMax-aMin+1)),b=bMin+Math.floor(Math.random()*(bMax-bMin+1));const id=++g.ticketSeq;const ticket={id,rarity,coinTier:rarity,orderLabel:pick(COIN_ORDER_LABELS[rarity]),orderIcon:COIN_ORDER_ICONS[rarity],a,b,base:ticketBase(rarity)};ticket.foodId=assignedOrderFood(ticket);return ticket}
function refillBoard(){while(g.board.length<ORDER_LIMIT)g.board.push(makeTicket())}
function reconcileAutoEquip(){if((!g.run||g.run.paused)&&['final','base'].includes(g.autoEquip)){const next=bestMenu(g.owned,g.menuSlots,g.autoEquip);if(JSON.stringify(next)!==JSON.stringify(g.activeMenu))g.activeMenu=next}}
function orderNow(){g.orderClock=Math.max(g.orderClock||0,Date.now());return g.orderClock}
function refreshRemaining(){return Math.max(0,(g.orderRefreshAt||0)-orderNow())}
function syncRefreshDeadline(){
 // Stale tabs and their staff ticks cannot erase an already-saved cooldown.
 try{const stored=JSON.parse(localStorage.getItem('panaderyaQuestV2'));if(stored?.orderRefreshAt>g.orderRefreshAt)g.orderRefreshAt=stored.orderRefreshAt;g.orderClock=Math.max(g.orderClock||0,stored?.orderClock||0)}catch(_){}
}
function refreshOrders(paid=false){
 syncRefreshDeadline();
 if(g.run){g.orderRuns[g.run.ticket.id]=g.run;if(!g.board.some(t=>t.id===g.run.ticket.id))g.board.unshift(g.run.ticket)}
 const eligible=g.board.filter(t=>!g.orderRuns[t.id]);if(!eligible.length&&g.board.length>=ORDER_LIMIT){toast('All orders have saved progress. Finish one to make room.');return false}
 if(refreshRemaining()>0&&!paid)return false;
 const cost=paid?refreshSkipCost():0;if(g.coins<cost)return false;
 commitPurchaseUndo('Order tickets refreshed');g.coins-=cost;
 g.orderRefreshAt=orderNow()+ORDER_REFRESH_MS;g.board=g.board.filter(t=>g.orderRuns[t.id]);refillBoard();save();render();toast('Fresh orders have arrived! Saved orders are kept.');return true;
}
function refreshSkipCost(){return Math.max(1,Math.round(economyUnit()*.5))}
function requestRefreshSkip(){const cost=refreshSkipCost();showModal('Refresh untouched orders?',`<p>Saved orders and their rewards stay exactly where they are.</p><button class="primary" ${g.coins<cost?'disabled':''} onclick="if(refreshOrders(true))closeModal()">Skip · 🪙 ${fmt(cost)}</button>`)}
function updateOrderRefresh(){const button=$('refreshOrders');if(!button)return;const remaining=refreshRemaining(),seconds=Math.ceil(remaining/1000);button.disabled=remaining>0;button.textContent=remaining?`Refresh in ${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`:'Refresh Orders';}
function save(){
 // Refuse to overwrite newer rewards or inventory from another tab.
 try{const stored=JSON.parse(localStorage.getItem('panaderyaQuestV2'));if(Object.keys(stored?.claimedOrders||{}).some(id=>!g.claimedOrders[id])){toast('Progress was collected in another tab. Reload to continue.');return false}if((stored?.packageRevision||0)>(g.packageRevision||0)){toast('Packages changed in another tab. Reload to continue.');return false}}catch(_){}
 reconcileAutoEquip();reconcileOrderFoods();g.economyPeakBase=pricingMenuBase();syncRefreshDeadline();orderNow();if(g.run)g.orderRuns[g.run.ticket.id]=g.run;if(typeof validatePurchaseUndo==='function')validatePurchaseUndo();try{localStorage.setItem('panaderyaQuestV2',JSON.stringify(g));return true}catch(_){if(typeof document.createElement==='function')toast('Saving is unavailable. Keep this page open to retain your progress.');return false}}
let toastTimer=null;
function positionNotifications(){
 const dock=$('notificationDock');if(!dock||(!g.purchaseUndo&&!$('toasts')?.childElementCount))return;
 // Prefer noninteractive illustration areas, keeping repeated purchase controls clear.
 for(const selector of ['.package-possible','.current-bakery-preview','.food-panel-scroll','.menu-grid','.order-narrative']){
  const anchor=document.querySelector(selector);if(!anchor)continue;
  const r=anchor.getBoundingClientRect(),top=Math.max(8,r.top),bottom=Math.min(innerHeight-8,r.bottom);
  if(r.width<160||r.left<0||r.right>innerWidth||bottom-top<60)continue;
  dock.style.width=Math.min(280,r.width-16)+'px';
  if(dock.offsetHeight>bottom-top-8)continue;
  dock.style.left=(r.left+8)+'px';
  dock.style.top=(selector==='.menu-grid'?top+4:bottom-dock.offsetHeight-4)+'px';
  return;
 }
 dock.style.left='12px';dock.style.width='min(280px, calc(100vw - 24px))';dock.style.top=Math.max(8,innerHeight-dock.offsetHeight-12)+'px';
}
function clearNotifications(){clearTimeout(toastTimer);const root=$('toasts');if(root)root.replaceChildren()}
function toast(text){
 const root=$('toasts');if(!root)return;
 clearNotifications();
 if(modal){let note=document.querySelector?.('.modal .dialog-notice');if(!note){note=document.createElement('p');note.className='dialog-notice';note.setAttribute('role','status');document.querySelector?.('.modalbody')?.appendChild(note)}note.textContent=text;return}
 const el=document.createElement('div');el.className='toast';el.textContent=text;root.appendChild(el);positionNotifications();toastTimer=setTimeout(()=>el.remove(),2800);
}
function captureFocus(el){return el?{node:el,id:el.id,key:el.getAttribute?.('data-focus'),action:el.getAttribute?.('onclick'),label:el.getAttribute?.('aria-label')}:null}
function restoreFocus(target){
 if(!target)return;let el=target.node?.isConnected?target.node:target.id?$(target.id):null;
 if(!el)el=[...(document.querySelectorAll?.('button,summary,[role="tab"]')||[])].find(node=>target.key?node.getAttribute('data-focus')===target.key:target.action?node.getAttribute('onclick')===target.action:target.label&&node.getAttribute('aria-label')===target.label);
 if(!el)el=document.querySelector?.('.iconbtn');el?.focus?.({preventScroll:true});
}
let modalTriggerFocus=null;
document.addEventListener?.('click',event=>{const trigger=event.target.closest?.('button,summary,[role="tab"]');if(trigger){modalTriggerFocus=captureFocus(trigger);setTimeout(()=>modalTriggerFocus=null,0)}},true);
function showModal(title,html,variant=''){if(modal?.variant?.includes('package-shop-modal')&&!variant.includes('package-shop-modal'))endPackageSession();if(!modal)modalReturnFocus=modalTriggerFocus||captureFocus(document.activeElement);clearNotifications();modal={title,html,variant};paintModal()}
function closeModal(){if(modal?.variant?.includes('package-shop-modal'))endPackageSession();const focus=modalReturnFocus;modal=null;modalReturnFocus=null;clearNotifications();paintModal();render();restoreFocus(focus)}
function paintModal(){
 const root=$('modals');if(!modal){root.innerHTML='';return}
 root.innerHTML=`<div class="backdrop ${modal.variant?.includes('package-shop-modal')?'':'bakery-overlay'}" onclick="if(event.target===this)closeModal()"><div class="modal ${modal.variant||''}" role="dialog" aria-modal="true" aria-labelledby="modalTitle" tabindex="-1"><div class="modalhead"><h2 id="modalTitle">${modal.title}</h2><span class="dialog-wallet">🪙 ${amountLabel(g.coins)}</span><button aria-label="Close" class="close" onclick="closeModal()">×</button></div><div class="modalbody">${modal.html}</div></div></div>`;
 if(typeof requestAnimationFrame==='function')requestAnimationFrame(()=>root.querySelector?.('.modal')?.focus());
}
document.addEventListener?.('keydown',event=>{
 if(!modal)return;
 if(event.key==='Escape'){event.preventDefault();closeModal();return}
 if(event.key!=='Tab')return;
 const root=document.querySelector('.modal');if(!root)return;
 const targets=[...root.querySelectorAll('button:not(:disabled),input:not(:disabled),select,summary,[tabindex="0"]')].filter(el=>el.getClientRects().length);
 if(!targets.length){event.preventDefault();root.focus();return}
 const first=targets[0],last=targets.at(-1);
 if(event.shiftKey&&(document.activeElement===first||document.activeElement===root)){event.preventDefault();last.focus()}
 else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===root)){event.preventDefault();first.focus()}
});
