/* Shared, deterministic progression rules. No DOM, random draws or transactions. */
const PROGRESSION_VERSION=3, MAX_FOOD_LEVEL=5, MAX_FOOD_TIER=5;
const TIER_FACTORS=[0,1,2,3.5,5.5,8], LEVEL_FACTORS=[0,1,1.25,1.55,1.9,2.3];
const TICKET_DIMS=[[2,1],[2,2],[2,2],[3,2],[3,2],[4,2],[4,2],[4,2]];
const ORDER_LIMIT=5, ORDER_REFRESH_MS=180000;
// Frame 11: tune progression and shop economy here, independently of presentation.
// Saved Bakery Power is archived during hub migration; it no longer progresses.
const PACKAGE_TYPES=['Standard','Lucky','Fortunate','Charmed','Blessed','Miraculous','Divine','Fate','Sovereign'];
const PACKAGE_SHOP=PACKAGE_TYPES.map((name,rank)=>({name,rank,unlock:ECONOMY_BALANCE.unlocks[rank],orders:[0,4,12,24,45,75,120,180,260][rank],priceOrders:ECONOMY_BALANCE.packageOrders*Math.pow(ECONOMY_BALANCE.packageGrowth,rank)}));
const MASTERY_STEP=.4, PURCHASE_UNDO_MS=10000;
function recipeMastery(o){return Math.max(0,Math.floor(o.mastery??((o.level||1)-1)))}
function masteryFactor(n){return n<5?LEVEL_FACTORS[n+1]:2.3+(n-4)*MASTERY_STEP}
function availableMastery(o){return Math.max(0,(g.recipeCeilings?.[o.id]||0)-recipeMastery(o))}
function foodTier(o){return clamp(Math.floor(Number(o.fusion)||1),1,MAX_FOOD_TIER)}
function amountLabel(value){return Math.abs(value)<1e6?fmt(value):largeNumberLabel(value,1)}
function multiplierLabel(value){return Math.abs(value)<1e4?value.toFixed(2):largeNumberLabel(value,2)}
function tierBase(o){return (FOOD.find(f=>f.id===o.id)?.base||0)*TIER_FACTORS[foodTier(o)]+Math.max(0,Number(o.baseCarry)||0)}
function individualValue(o){return tierBase(o)*masteryFactor(recipeMastery(o))}
// One retained instance per Food Index recipe. Legacy investments consolidate once.
function consolidateOwnedFoods(state){
 const groups=new Map();for(const o of state.owned){if(!groups.has(o.id))groups.set(o.id,[]);groups.get(o.id).push(o)}
 const replacements=new Map();let changed=false;
 state.owned=[...groups.values()].map(copies=>{
  const strongest=[...copies].sort((a,b)=>individualValue(b)-individualValue(a)||a.uid-b.uid)[0];
  const keep=copies.find(o=>state.activeMenu.includes(o.uid))||strongest;
  for(const o of copies)replacements.set(o.uid,keep.uid);
  if(copies.length===1)return keep;
  changed=true;const maximum=Math.max(...copies.map(individualValue)),mastery=Math.max(...copies.map(recipeMastery));
  const fusion=Math.max(...copies.map(foodTier)),base=FOOD.find(f=>f.id===keep.id)?.base||0;
  const result={...keep,mastery,level:Math.min(5,mastery+1),fusion,
   spent:copies.reduce((n,o)=>n+(o.spent||0),0),resaleBase:copies.reduce((n,o)=>n+foodResaleBase(o),0)};
  result.baseCarry=Math.max(keep.baseCarry||0,maximum/masteryFactor(mastery)-base*TIER_FACTORS[fusion],0);
  state.recipeCeilings[keep.id]=Math.max(state.recipeCeilings[keep.id]||0,mastery,copies.length-1);
  return result;
 });
 state.menuSlots=clamp(state.menuSlots,1,FOOD.length);
 state.activeMenu=[...new Set(state.activeMenu.map(uid=>replacements.get(uid)).filter(uid=>uid!==undefined))].slice(0,state.menuSlots);
 if(changed||state.purchaseUndo?.before?.owned&&new Set(state.purchaseUndo.before.owned.map(o=>o.id)).size!==state.purchaseUndo.before.owned.length)state.purchaseUndo=null;
 state.uniqueFoodsVersion=1;return state;
}
function bakeryFactor(){return 1} // compatibility for archived saves/tools; never grants Power
function powerLabel(value){return Math.abs(value)>=1e6?largeNumberLabel(value,2):new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(value)}
// Display rounding is independent of the probability used by the random draw.
function probabilityLabel(probability){const percent=probability*100;return percent>0&&percent<.01?'<0.01%':percent.toFixed(2)+'%'}
function binomialRanks(p){
 const coefficients=[1,7,21,35,35,21,7,1];
 const weights=coefficients.map((c,i)=>c*Math.pow(p,i)*Math.pow(1-p,7-i));
 const total=weights.reduce((a,b)=>a+b,0);return weights.map(w=>w/total);
}
// Increasing p couples seven Bernoulli draws: every upper tail is nondecreasing.
function ticketProbabilities(mastery){return binomialRanks(.04+.68*(1-Math.exp(-Math.max(0,mastery||0)/80)))}
function packageProbabilities(packageRank){return binomialRanks(packageRank>=8?.97:.08+.84*clamp(packageRank,0,7)/7)}
function drawRank(probabilities,random=Math.random()){
 let cumulative=0;for(let i=0;i<probabilities.length;i++){cumulative+=probabilities[i];if(random<cumulative)return i}return probabilities.length-1;
}
const COIN_TIERS=['Coin Stack','Coin Jar','Coin Bag','Coin Bucket','Coin Cart','Treasure Chest','Golden Vault','Divine Treasury'];
const COIN_ORDER_LABELS=[['Snack Order','Breakfast Order'],['Family Order','Picnic Order'],['School Order','Party Order'],['Cafe Order','Market Order'],['Hotel Order','Festival Order'],['Town Order','Banquet Order'],['Palace Order','Royal Order'],['Grand Feast','Celebration Order']];
const COIN_ORDER_ICONS=['🏠','🧺','🏫','☕','🏨','🏘️','🏰','🌟'];
function ticketCoinTier(ticket){return clamp(Number.isInteger(ticket.coinTier)?ticket.coinTier:ticket.rarity||0,0,7)}
function ticketOrderLabel(ticket){return ticket.orderLabel||COIN_ORDER_LABELS[ticketCoinTier(ticket)][Math.abs(Number(ticket.id)||0)%2]}
function ticketBase(rank){return Math.round(ECONOMY_BALANCE.coinBase*ECONOMY_BALANCE.coinGrowth**clamp(rank,0,7))}
function expectedTicketBase(mastery){return ticketProbabilities(mastery).reduce((sum,p,i)=>sum+p*ticketBase(i),0)}
function tierRecipe(a,b){
 if(!Number.isInteger(a)||!Number.isInteger(b)||a<1||b<1||a>=5||b>=5)return null;
 const sum=a+b;return sum>5?[5,sum-5]:a===b&&a>1?[sum-1,1]:[sum];
}
function splitInteger(total,weights){
 const sum=weights.reduce((a,b)=>a+b,0);let remaining=Math.floor(total);
 return weights.map((weight,i)=>{const part=i===weights.length-1?remaining:Math.floor(total*weight/sum);remaining-=part;return part});
}
function foodResaleBase(o){return Number.isFinite(o.resaleBase)?Math.max(0,Math.floor(o.resaleBase)):Math.round((FOOD.find(f=>f.id===o.id)?.base||0)*45)}
function fusionPlan(a,b,fee){
 if(!a||!b||a.uid===b.uid||a.id!==b.id)return null;
 const tiers=tierRecipe(foodTier(a),foodTier(b));if(!tiers)return null;
 let progress=(a.level-1)+(b.level-1);
 const outputs=tiers.map(fusion=>{const points=Math.min(4,progress);progress-=points;return {id:a.id,fusion,level:points+1,spent:0,baseCarry:0,resaleBase:0}});
 const incoming=[individualValue(a),individualValue(b)],totalBefore=incoming.reduce((s,v)=>s+v,0);
 const others=outputs.slice(1).reduce((s,o)=>s+individualValue(o),0);
 const primaryMinimum=Math.max(...incoming,totalBefore-others);
 const carry=Math.max(0,primaryMinimum-individualValue(outputs[0]));
 outputs[0].baseCarry=carry/LEVEL_FACTORS[outputs[0].level];
 const values=outputs.map(individualValue),investment=Math.floor((a.spent||0)+(b.spent||0)+fee);
 const spent=splitInteger(investment,values),resale=splitInteger(foodResaleBase(a)+foodResaleBase(b),values);
 outputs.forEach((o,i)=>{o.spent=spent[i];o.resaleBase=resale[i]});
 return {inputs:[a.uid,b.uid],outputs,fee,levelCredits:progress,investment,totalBefore,totalAfter:values.reduce((s,v)=>s+v,0),strongestBefore:Math.max(...incoming),strongestAfter:Math.max(...values)};
}
function bestMenu(owned,capacity,mode){
 const sorted=[...owned].filter(o=>FOOD.some(f=>f.id===o.id)).sort((a,b)=>
  (mode==='base'?tierBase(b)-tierBase(a):individualValue(b)-individualValue(a))||individualValue(b)-individualValue(a)||a.uid-b.uid);
 const seen=new Set();return sorted.filter(o=>{if(seen.has(o.id))return false;seen.add(o.id);return true}).slice(0,capacity).map(o=>o.uid);
}
function pricingMenuBase(){
 return Math.max(1,g.economyPeakBase||0,foodSum());
}

function migrateProgression(state){
 if(state.progressionVersion>=PROGRESSION_VERSION)return state;
 const ranks=[...(state.board||[]).map(t=>t.rarity),state.run?.ticket?.rarity,...(state.run?.chests||[]).map(c=>typeof c==='number'?c:c.rarity)];
 const seven=state.rarityCount===7||state.rarityNames?.length===7||ranks.includes(6);
 const map=seven?[0,1,2,3,4,6,7]:[0,1,2,3,4,7];
 const migrateRank=r=>map[clamp(Math.floor(r||0),0,map.length-1)];
 for(const ticket of state.board||[])ticket.rarity=migrateRank(ticket.rarity);
 if(state.run?.ticket)state.run.ticket.rarity=migrateRank(state.run.ticket.rarity);
 if(state.run?.chests)state.run.chests=state.run.chests.map(c=>typeof c==='number'?migrateRank(c):{...c,rarity:migrateRank(c.rarity)});
 for(const o of state.owned||[]){o.fusion=clamp((Number(o.fusion)||0)+1,1,5);o.level=clamp(Number(o.level)||1,1,5);o.spent=Math.max(0,Number(o.spent)||0)}
 const oldDecor=clamp(state.decor||0,0,4),oldBonus=[1,1.08,1.19,1.35,1.55][oldDecor];
 state.bakeryLevel=Math.max(state.bakeryLevel||1,Math.ceil(Math.log(oldBonus)/Math.log(1.085)-1e-10)+1);
 state.bakerySpent=state.bakerySpent??[550,2200,8800,35000].slice(0,oldDecor).reduce((a,b)=>a+b,0);
 state.legacyDecor=state.legacyDecor??oldDecor;state.decor=oldDecor;
 state.autoEquip=['final','base'].includes(state.autoEquip)?state.autoEquip:'off';
 state.foodLevelCredits=state.foodLevelCredits||{};
 state.ticketSeq=Math.max(state.ticketSeq||0,...(state.board||[]).map(t=>Number(t.id)||0),Number(state.run?.ticket?.id)||0);
 state.uidNext=Math.max(state.uidNext||1,...(state.owned||[]).map(o=>(Number(o.uid)||0)+1));
 state.orderClock=Math.max(0,Number(state.orderClock)||0);state.orderRefreshAt=Math.max(0,Number(state.orderRefreshAt)||0);
 state.rarityCount=8;state.progressionVersion=PROGRESSION_VERSION;return state;
}

function themeLevel(){return Math.min(4,Math.floor(g.completed/30))}
