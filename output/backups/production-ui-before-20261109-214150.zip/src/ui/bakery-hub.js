/* A presentation adapter for the existing state/transactions and worksheet bridge. */
let hubCollection=false,hubMountedRun=null,hubMountedPhase=null;
function isBakeryHub(){return typeof document!=='undefined'&&document.body?.dataset.view==='hub'}
function boostSparkle(){return `<span class="boost-sparkle" aria-hidden="true"><svg viewBox="0 0 64 80"><path d="M32 2C35 27 39 33 57 39C39 43 36 51 31 78C28 53 25 46 7 41C24 36 29 29 32 2Z" fill="currentColor"/><path d="M32 10C32 30 33 35 48 39C34 40 33 49 31 68C31 49 29 43 17 41C29 39 31 32 32 10Z" fill="#fff" opacity=".65"/></svg><i></i></span>`}
function hubIcon(name){
 const drawings={chef:'<path d="M17 34C2 32 4 12 19 14 22 2 42 2 45 14 61 11 64 33 48 35v19H17Z" fill="#fff1d1" stroke="#9e6642" stroke-width="3"/><path d="M17 44h31" stroke="#d49b6b" stroke-width="3"/>',package:'<rect x="10" y="24" width="44" height="32" rx="4" fill="#dfac6f"/><rect x="7" y="20" width="50" height="12" rx="3" fill="#ffe5af"/><path d="M32 21v35M30 20C1 19 15-5 30 20Zm4 0C64 19 49-5 34 20Z" fill="#f8d793" stroke="#93603d" stroke-width="3"/>',coin:'<circle cx="32" cy="32" r="27" fill="#f7c65c" stroke="#bd843d" stroke-width="3"/><circle cx="32" cy="32" r="20" fill="none" stroke="#ffe9a5" stroke-width="3"/><path d="M39 21c-18-12-28 11-8 12 20 2 8 24-8 10m9-29v36" fill="none" stroke="#af7135" stroke-width="4"/>',menu:'<ellipse cx="32" cy="40" rx="26" ry="15" fill="#e3a25c" stroke="#996237" stroke-width="3"/><path d="M8 36c2-24 45-27 48 0M23 17l5 12m10-13 5 12" fill="#ffdb97" stroke="#b67b43" stroke-width="3"/>'};
 return `<span class="hub-icon" aria-hidden="true">${drawings[name]?`<svg viewBox="0 0 64 64">${drawings[name]}</svg>`:bakeryIcon(name)}</span>`;
}
function renderHubHome(){
 const foods=g.activeMenu.map(uid=>g.owned.find(o=>o.uid===uid)).filter(Boolean),n=foods.length;
 const {columns,rows,width}=globalThis.BakeryLayout.showcase(n);
 return `<header class="hub-brand"><h1>My Panaderya</h1></header>
 <div class="hub-wallet"><button onclick="showCoinsInfo()" aria-label="About your coins">${hubIcon('coin')}<strong id="walletCoins">${amountLabel(g.coins)}</strong><span class="wallet-plus">+</span></button><button class="hub-round" onclick="showTutorial()" aria-label="Help">?</button><button class="hub-round" onclick="openSettings()" aria-label="Settings">${hubIcon('settings')}</button></div>
 <section class="hub-packages" aria-labelledby="hubPackagesHeading"><img class="package-shelf-art" src="assets/illustrated/shelf.webp" alt="" aria-hidden="true" draggable="false"><h2 class="hub-plaque" id="hubPackagesHeading">${hubIcon('package')} Packages</h2><div class="hub-package-grid">${PACKAGE_SHOP.map(t=>`<button class="hub-package package-tier-${t.rank}" data-rank="${t.rank}" onclick="openPackages('buy',${t.rank})" aria-label="${t.rank+1}. ${t.name} package, ${packageUnlocked(t.rank)?`${amountLabel(packagePrice(t.rank))} coins`:`unlocks at ${t.orders} completed orders`}">${bakeryPackageArt(t.rank)}<b class="package-tier-number">${t.rank+1}</b>${g.packages[t.rank]?`<span class="hub-stock">${amountLabel(g.packages[t.rank])}</span>`:''}</button>`).join('')}</div></section>
 <section class="hub-showcase" aria-labelledby="hubShowcaseHeading"><div class="showcase-heading"><h2 id="hubShowcaseHeading">Menu Collection</h2><button class="hub-total-boost boost-counter" onclick="showBoostInfo()" aria-label="Baker's Boost ×${multiplierLabel(bakeryValue())}">${boostSparkle()}<span><small>BAKER'S BOOST</small><strong id="bakerBoost">×${multiplierLabel(bakeryValue())}</strong></span></button></div>
 <div class="showcase-cabinet" style="--cabinet-width:${width}%;--visible-rows:${Math.min(rows,3)}" data-count="${n}"><div class="showcase-scroll" tabindex="0" aria-label="Equipped food showcase, scroll to browse"><div class="showcase-grid" style="--columns:${columns}">${foods.map((o,i)=>{const f=F(o.id),row=Math.floor(i/columns),inRow=Math.min(columns,n-row*columns),column=columns-inRow+(i%columns)*2+1;
 return `<button class="hub-food r${f.rarity}" style="grid-column:${column}/span 2;grid-row:${row+1}" data-food="${f.id}" data-uid="${o.uid}" data-rarity="${f.rarity}" onclick="openHubFood(${o.uid})" aria-label="Manage ${f.name}, Baker's Boost ×${multiplierLabel(foodValue(o))}"><span class="food-aura" aria-hidden="true"></span>${bakeryFoodArt(f.id)}<span class="compartment-glass" aria-hidden="true"></span><span class="food-boost-tag">${boostSparkle()}×${multiplierLabel(foodValue(o))}</span></button>`}).join('')}</div>${n?'':'<button class="showcase-empty" onclick="openHubCollection()">Choose a recipe<br><small>from your collection</small></button>'}</div></div></section>
 <section class="hub-orders" aria-labelledby="hubOrdersHeading"><h2 class="hub-plaque" id="hubOrdersHeading">${hubIcon('ticket')} Orders</h2><div class="hub-order-scroll tickets" tabindex="0" aria-label="Available orders, scroll for more">${g.board.map(t=>{const r=g.orderRuns[t.id],tier=ticketCoinTier(t),p=ticketProgress(t),food=orderFood(t);return `<button class="hub-ticket ticket coin-tier-${tier}" data-ticket-id="${t.id}" data-order-food="${food.id}" onclick="startTicket(${t.id})" aria-label="${r?.phase==='claim'?'Collect':r?'Resume':'Start'} ${food.name}, ${t.a} × ${t.b}, ${COIN_TIERS[tier]}"><span class="ticket-food">${bakeryFoodArt(food.id)}<b>${food.name}</b>${r?`<small>${r.phase==='claim'?'Collect':`${p}% · Resume`}</small>`:''}</span><span class="hub-ticket-reward">${coinTierArt(tier)}<b>${COIN_TIERS[tier]}</b></span><span class="hub-ticket-problem"><strong>${t.a} <span>×</span> ${t.b}</strong></span><span class="ticket-play" aria-hidden="true">▸</span></button>`}).join('')}</div><button class="hub-refresh" id="refreshOrders" onclick="refreshOrders()">Refresh Orders</button><button class="hub-odds" onclick="openProbabilities()">Reward odds</button></section>
 <nav class="hub-navigation" aria-label="Bakery"><button class="hub-nav-button" onclick="openPackages()">${hubIcon('package')}<span>Packages</span></button><button class="hub-nav-button hub-play" onclick="playHubOrder()">${hubIcon('chef')}<span>${g.run?'Resume Order':'Play Orders'}</span><span aria-hidden="true">▸</span></button><button class="hub-nav-button" onclick="openHubCollection()">${hubIcon('menu')}<span>Menu<br>Collection</span></button></nav>`;
}
function syncHubScene(){const scene=$('bakeryScene');if(scene&&!scene.firstChild)scene.innerHTML=renderIllustratedRoom();if(scene)scene.dataset.rendered='true'}
function openHubCollection(){hubCollection=true;render();document.querySelector('.hub-collection-back')?.focus()}
function closeHubCollection(){selectedFoods.clear();hubCollection=false;render()}
function openHubFood(uid){hubCollection=true;selectedFoods=new Set([uid]);multiSelect=false;render();document.querySelector('.food-panel-close')?.focus()}
function playHubOrder(){const t=g.run?.ticket||g.board.find(t=>g.orderRuns[t.id])||g.board[0];if(t){hubCollection=false;startTicket(t.id)}}
function renderBakeryHub(){
 reconcileAutoEquip();refillBoard();reconcileOrderFoods();
 if(!$('hubHome'))$('app').innerHTML=`<div id="hubHome" class="hub-home"></div><div id="hubCollection" class="hub-collection" hidden></div><div id="hubOrder" class="hub-order-workspace" hidden></div>`;
 const playing=!!g.run&&!g.run.paused,home=$('hubHome'),collection=$('hubCollection'),order=$('hubOrder');
 if(playing)hubCollection=false;
 home.hidden=playing||hubCollection;collection.hidden=playing||!hubCollection;order.hidden=!playing;
 document.body.classList.toggle('hub-working',playing||hubCollection);
 $('app').className=playing?'playing':'browsing';
 const foodScroll=home.querySelector('.showcase-scroll')?.scrollTop||0,orderScroll=home.querySelector('.hub-order-scroll')?.scrollTop||0;
 // Keep the focused worksheet and its history mounted during visits to the bakery.
 if(!playing){home.innerHTML=renderHubHome();home.querySelector('.showcase-scroll').scrollTop=foodScroll;home.querySelector('.hub-order-scroll').scrollTop=orderScroll;
  if(hubCollection){const scroll=collection.querySelector('.menu-grid')?.scrollTop||0;collection.innerHTML=`<button class="hub-collection-back secondary" onclick="closeHubCollection()">‹ Back to bakery</button>${renderMenu()}`;collection.querySelector('.menu-grid').scrollTop=scroll;}
 }
 if(g.run&&(hubMountedRun!==g.run||hubMountedPhase!==g.run.phase||!order.firstChild)){
  hubMountedRun=g.run;hubMountedPhase=g.run.phase;order.innerHTML=renderWorksheet();
  if(g.run.phase==='engine'){const fr=$('worksheetFrame');fr.onload=()=>sendEngine('hello');fr.src='worksheet/worksheet-engine.html'}
 }else if(!g.run){hubMountedRun=null;hubMountedPhase=null;order.replaceChildren()}
 if(playing&&g.run.phase==='engine')requestAnimationFrame(()=>fitWorksheet());
 if(typeof syncRewardPresentation==='function')syncRewardPresentation();
 paintPurchaseUndo();updateOrderRefresh();syncHubScene();
}
