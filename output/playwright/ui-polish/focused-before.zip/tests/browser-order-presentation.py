"""Actual Orders: die-cut masks, stationary controls, tier finishes and grounded register."""
import importlib.util,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
spec=importlib.util.spec_from_file_location('ui_support',Path(__file__).with_name('browser-ui-replacement.py'))
support=importlib.util.module_from_spec(spec);spec.loader.exec_module(support)
ROOT=support.ROOT;OUT=ROOT/'output/playwright/orders-refinement';OUT.mkdir(parents=True,exist_ok=True);support.OUT=OUT
def fixture(p):
 p.evaluate('''()=>{g.run=null;g.orderRuns={};g.board=Array.from({length:8},(_,rank)=>({id:9100+rank,rarity:rank,coinTier:rank,orderLabel:COIN_ORDER_LABELS[rank][1],orderIcon:COIN_ORDER_ICONS[rank],foodId:'pandesal',a:rank<3?79:rank<5?799:9876,b:rank?98:9,base:ticketBase(rank)}));render();save()}''')
 p.wait_for_function("[...document.querySelectorAll('#stage img')].every(i=>i.complete&&i.naturalWidth)")
def metrics(p):
 return p.evaluate('''()=>{const box=s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,right:r.right,bottom:r.bottom}},stage=box('#stage'),board=box('#orders-board'),list=box('#order-scroller'),heading=box('.board-title'),utilities=box('.board-utilities'),register=box('.register-art');return {stage,board,list,heading,utilities,register}}''')
def run(pw,engine):
 b=pw.webkit.launch() if engine=='webkit' else pw.chromium.launch(channel='msedge')
 c=b.new_context(viewport={'width':2000,'height':1200},has_touch=True);p=c.new_page();errors=[]
 p.on('pageerror',lambda e:errors.append(str(e)));p.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
 try:
  p.goto(support.URL);p.wait_for_selector('.hub-ticket');p.wait_for_load_state('networkidle')
  support.screenshot(p,f'{engine}-starter-home')
  fixture(p)
  path=ET.parse(ROOT/'assets/bakery-ui/order-ticket-mask.svg').getroot()[0].attrib['d']
  assert p.locator('.ticket-outer-edge').evaluate_all('es=>es.map(e=>e.getAttribute("d"))')==[path]*8
  assert p.locator('.ticket-cutout').evaluate_all('es=>es.every(e=>getComputedStyle(e).maskImage.includes("order-ticket-mask.svg")||getComputedStyle(e).webkitMaskImage.includes("order-ticket-mask.svg"))')
  assert p.locator('.ticket-play,.ticket-reward,.coin-hero small').count()==0
  for rank in range(8):
   ticket=p.locator(f'.hub-ticket.coin-tier-{rank}')
   assert ticket.locator('.ticket-sparkles').count()==int(rank>=4)
   assert ticket.locator('.ticket-rays').count()==int(rank>=3)
   assert ticket.locator('.ticket-light-sweep').count()==int(rank>=6)
   assert ticket.locator('.ticket-iridescence').count()==int(rank==7)
  for width,height in [(2000,1200),(1280,800),(1024,768)]:
   p.set_viewport_size({'width':width,'height':height});support.top(p,'#order-scroller');p.wait_for_timeout(100)
   m=metrics(p);s=m['stage'];r=m['register'];l=m['list'];bnd=m['board'];h=m['heading'];u=m['utilities']
   assert h['bottom']<=u['y'] and u['bottom']<l['y'],m
   assert l['bottom']<=r['y']<bnd['bottom'],m
   assert s['y']+s['h']*.76<r['bottom']<s['y']+s['h']*.825,m
   assert p.locator('.register-art').get_attribute('src').endswith('cash-register-facing.png')
   assert p.locator('.ticket-safe-content').evaluate_all('''es=>es.every(e=>{const r=e.getBoundingClientRect(),p=e.parentElement.getBoundingClientRect();return r.left>p.left+8&&r.right<p.right-8&&r.top>p.top&&r.bottom<p.bottom})''')
   assert p.locator('.order-math,.order-name,.hub-ticket-progress').evaluate_all('es=>es.every(e=>e.scrollWidth<=e.clientWidth+1&&e.scrollHeight<=e.clientHeight+1)')
   assert p.locator('.board-utilities button').evaluate_all('es=>es.every(e=>e.getBoundingClientRect().height>=43.8)')
   for rank in range(8):
    ticket=p.locator(f'.hub-ticket.coin-tier-{rank}');ticket.scroll_into_view_if_needed();p.wait_for_timeout(120)
    ticket.screenshot(path=str(OUT/f'{engine}-{width}-tier-{rank+1}.png'),animations='disabled')
   support.top(p,'#order-scroller');support.screenshot(p,f'{engine}-{width}-top')
   support.test_scroll(p,engine,'#order-scroller','#board-scroll-track','#board-scroll-thumb','[data-hub-action="order-down"]')
   now=metrics(p);assert now['heading']==m['heading'] and now['utilities']==m['utilities'] and now['register']==m['register']
   support.screenshot(p,f'{engine}-{width}-scrolled')
  # Highest-tier motions preserve content bounds, and reduced motion disables them.
  p.set_viewport_size({'width':1280,'height':800});p.locator('.coin-tier-7').scroll_into_view_if_needed();p.wait_for_timeout(200)
  before=p.locator('.coin-tier-7 .ticket-safe-content').bounding_box();p.wait_for_timeout(350)
  assert p.locator('.coin-tier-7 .ticket-safe-content').bounding_box()==before
  assert p.locator('.coin-tier-7 .ticket-light-sweep').evaluate('e=>getComputedStyle(e).animationName')=='order-sweep'
  p.emulate_media(reduced_motion='reduce')
  assert p.locator('.ticket-sparkles i,.ticket-light-sweep,.ticket-iridescence').evaluate_all('es=>es.every(e=>getComputedStyle(e).animationName==="none")')
  support.screenshot(p,f'{engine}-reduced-motion');p.emulate_media(reduced_motion='no-preference')
  # Tap the actual reward-art region: the whole ticket starts its real worksheet.
  ticket=p.locator('.hub-ticket.coin-tier-3');box=ticket.bounding_box();ticket.tap(position={'x':box['width']*.17,'y':box['height']*.4});p.wait_for_function("$('worksheetFrame')?.contentWindow.__ACTIVE_WORKSHEET_TICKET?.id===9103")
  assert p.locator('#worksheetFrame').get_attribute('src')=='worksheet/worksheet-engine.html'
  p.evaluate("window.orderFrame=$('worksheetFrame');window.orderBudget=g.run.budget")
  p.locator('.worksheet-exit').tap();p.locator('[data-ticket-id="9103"]').tap()
  assert p.evaluate("orderFrame===$('worksheetFrame')&&orderBudget===g.run.budget")
  p.locator('.worksheet-exit').tap();budget=p.evaluate('g.run.budget');p.reload();p.wait_for_selector('.hub-ticket')
  p.locator('[data-ticket-id="9103"]').tap();assert p.evaluate('g.run.budget')==budget
  assert not errors,errors
  (OUT/f'{engine}-results.json').write_text(json.dumps({'passed':True,'viewports':[[2000,1200],[1280,800],[1024,768]],'all_existing_tiers':8,'die_cut_mask_matches_artwork':True,'mouse_touch_scrollbar_keyboard':True,'stationary_heading_controls':True,'register_grounded_and_clear_of_tickets':True,'reduced_motion':True,'original_worksheet_resume_reload':True,'errors':errors},indent=2))
  print('PASS',engine,'order presentation: matched silhouettes, all tiers, scrolling, stationary controls, grounded register, reduced motion and original worksheet resume/reload',flush=True)
 except Exception:
  support.screenshot(p,f'{engine}-FAILURE');print('ERRORS',errors,flush=True);raise
 finally:b.close()
try:
 with support.sync_playwright() as pw:
  for engine in sys.argv[1:] or ['edge','webkit']:run(pw,engine)
finally:support.server.shutdown()
